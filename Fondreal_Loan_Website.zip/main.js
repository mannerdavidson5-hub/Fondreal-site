
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBFZ2EuxqXv3qUcncKSI6_sJLiBa-6GTMg",
  authDomain: "fondorealprestamo.firebaseapp.com",
  projectId: "fondorealprestamo",
  storageBucket: "fondorealprestamo.firebasestorage.app",
  messagingSenderId: "470363976429",
  appId: "1:470363976429:web:494f40eea5194be9bad2e4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

window.signUp = function() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  createUserWithEmailAndPassword(auth, email, password)
    .then(() => alert("Account created!"))
    .catch(err => alert(err.message));
};

window.login = function() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  signInWithEmailAndPassword(auth, email, password)
    .then(() => alert("Logged in!"))
    .catch(err => alert(err.message));
};

onAuthStateChanged(auth, (user) => {
  if (user) {
    document.getElementById("user-status").innerText = "Logged in as: " + user.email;
    document.getElementById("loan-form").style.display = "block";
  } else {
    document.getElementById("user-status").innerText = "Not logged in.";
    document.getElementById("loan-form").style.display = "none";
  }
});
