import React, { useState } from "react";

const texts = {
  en: {
    welcome: "Welcome to Fondreal! Your Trusted Loan Partner.",
    createAccount: "Create Your Account",
    fullName: "Full Name",
    idNumber: "ID Number",
    phone: "Phone Number (WhatsApp)",
    email: "Email Address",
    loanAmount: "Select Loan Amount",
    selectLoan: "--Select--",
    verificationCode: "Enter Verification Code",
    verify: "Verify",
    incorrectCode: "Incorrect verification code. Please try again.",
    payInstructions:
      "Please pay $200 USDT (ERC20) to wallet address: 0x9eAd7D542e49F18F82b73dbFE3B08c9c0ca20d33 to finalize your loan approval.",
    thankYou: "Thank you! Your loan application is complete.",
    whatsappHelp: "Need help? Chat with us on WhatsApp!",
    next: "Next",
    submit: "Submit",
  },
  es: {
    welcome: "¡Bienvenido a Fondreal! Su Socio Confiable de Préstamos.",
    createAccount: "Cree Su Cuenta",
    fullName: "Nombre Completo",
    idNumber: "Número de Cédula",
    phone: "Número de Teléfono (WhatsApp)",
    email: "Correo Electrónico",
    loanAmount: "Seleccione Monto del Préstamo",
    selectLoan: "--Seleccione--",
    verificationCode: "Ingrese Código de Verificación",
    verify: "Verificar",
    incorrectCode: "Código incorrecto. Inténtelo de nuevo.",
    payInstructions:
      "Por favor pague $200 USDT (ERC20) a la dirección de wallet: 0x9eAd7D542e49F18F82b73dbFE3B08c9c0ca20d33 para finalizar la aprobación de su préstamo.",
    thankYou: "¡Gracias! Su solicitud de préstamo está completa.",
    whatsappHelp: "¿Necesita ayuda? ¡Chatee con nosotros en WhatsApp!",
    next: "Siguiente",
    submit: "Enviar",
  },
};

const correctVerificationCode = "123456"; // Replace with your real code management

function App() {
  const [lang, setLang] = useState("en");
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: "",
    idNumber: "",
    phone: "",
    email: "",
    loanAmount: "",
  });
  const [verificationCode, setVerificationCode] = useState("");
  const [error, setError] = useState("");

  const t = texts[lang];

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleNextFromForm = () => {
    const { fullName, idNumber, phone, email } = formData;
    if (!fullName || !idNumber || !phone || !email) {
      alert(lang === "en" ? "Please fill all fields." : "Por favor complete todos los campos.");
      return;
    }
    setStep(2);
    alert(
      lang === "en"
        ? `Verification code sent via WhatsApp (demo code: ${correctVerificationCode})`
        : `Código de verificación enviado por WhatsApp (código demo: ${correctVerificationCode})`
    );
  };

  const handleVerifyCode = () => {
    if (verificationCode === correctVerificationCode) {
      setStep(3);
      setError("");
    } else {
      setError(t.incorrectCode);
    }
  };

  const handleSubmitFinal = () => {
    if (!formData.loanAmount) {
      alert(lang === "en" ? "Please select a loan amount." : "Por favor seleccione un monto.");
      return;
    }
    setStep(4);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", maxWidth: 500, margin: "auto", padding: 20 }}>
      <div style={{ textAlign: "right", marginBottom: 10 }}>
        <button onClick={() => setLang(lang === "en" ? "es" : "en")}>
          {lang === "en" ? "ES" : "EN"}
        </button>
      </div>

      <h1>{t.welcome}</h1>

      {step === 1 && (
        <>
          <h2>{t.createAccount}</h2>
          <label>
            {t.fullName}:<br />
            <input
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              type="text"
              style={{ width: "100%", marginBottom: 10 }}
            />
          </label>
          <label>
            {t.idNumber}:<br />
            <input
              name="idNumber"
              value={formData.idNumber}
              onChange={handleChange}
              type="text"
              style={{ width: "100%", marginBottom: 10 }}
            />
          </label>
          <label>
            {t.phone}:<br />
            <input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              type="tel"
              style={{ width: "100%", marginBottom: 10 }}
            />
          </label>
          <label>
            {t.email}:<br />
            <input
              name="email"
              value={formData.email}
              onChange={handleChange}
              type="email"
              style={{ width: "100%", marginBottom: 10 }}
            />
          </label>

          <button onClick={handleNextFromForm}>{t.next}</button>
        </>
      )}

      {step === 2 && (
        <>
          <h2>{t.verificationCode}</h2>
          <input
            type="text"
            placeholder={t.verificationCode}
            value={verificationCode}
            onChange={(e) => setVerificationCode(e.target.value)}
            style={{ width: "100%", marginBottom: 10 }}
          />
          <button onClick={handleVerifyCode}>{t.verify}</button>
          {error && <p style={{ color: "red" }}>{error}</p>}
        </>
      )}

      {step === 3 && (
        <>
          <h2>{t.loanAmount}</h2>
          <select
            value={formData.loanAmount}
            onChange={(e) => setFormData({ ...formData, loanAmount: e.target.value })}
            style={{ width: "100%", marginBottom: 10 }}
          >
            <option value="">{t.selectLoan}</option>
            <option value="10000">$10,000</option>
            <option value="15000">$15,000</option>
            <option value="20000">$20,000</option>
            <option value="25000">$25,000</option>
            <option value="30000">$30,000</option>
          </select>
          <button onClick={handleSubmitFinal}>{t.submit}</button>
        </>
      )}

      {step === 4 && (
        <>
          <h2>{t.payInstructions}</h2>
          <p>
            <strong>0x9eAd7D542e49F18F82b73dbFE3B08c9c0ca20d33</strong>
          </p>
          <p>{t.thankYou}</p>
          <p>{t.whatsappHelp}</p>
          <a
            href="https://wa.me/15598940066"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-block",
              padding: "10px 20px",
              backgroundColor: "#25D366",
              color: "#fff",
              borderRadius: "5px",
              textDecoration: "none",
            }}
          >
            WhatsApp
          </a>
        </>
      )}

      {/* Floating WhatsApp button */}
      <a
        href="https://wa.me/15598940066"
        target="_blank"
        rel="noopener noreferrer"
        style={{
          position: "fixed",
          bottom: 20,
          right: 20,
          backgroundColor: "#25D366",
          color: "#fff",
          borderRadius: "50%",
          padding: 15,
          fontSize: 24,
          boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
          textAlign: "center",
          textDecoration: "none",
          zIndex: 1000,
        }}
      >
        🟢
      </a>
    </div>
  );
}

export default App;
